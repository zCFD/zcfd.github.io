---
title: Choosing a wall model
section: guide
group: Choosing…
order: 20
---

# Choosing a wall model

Which wall model should a wall boundary use, and what does the choice ask of the mesh?

Use `no slip` when the mesh resolves the boundary layer, with the first cell at $y^{+}$ between 1 and 5. Use
`wall function` when the first cell lies clear of the viscous sublayer, at $y^{+}$ between 30 and 250, where the law of
the wall is applied. Use `slip` where the wall should exert no shear. Use the compressible wall function on a heated wall or at speed.
Giving the wall a temperature or a heat flux selects it.

| [`kind`](/reference/model/boundary-conditions/wall#kind) | First cell $y^{+}$                       | At the wall                                      |
| -------------------------------------------------------- | ---------------------------------------- | ------------------------------------------------ |
| `slip`                                                   | any                                      | zero momentum normal to the wall, no shear       |
| `no slip`                                                | 1 to 5, in the viscous sublayer          | the no-slip condition, applied directly          |
| `wall function`                                          | 30 to 250, clear of the viscous sublayer | the law of the wall, from the first cell's state |

Good practice is to target $y^{+} = 1$ on a wall-resolved mesh and $y^{+} = 100$ on a wall-modelled mesh.

## Slip, no slip or wall function {#kind}

The [`kind`](/reference/model/boundary-conditions/wall#kind) of a wall boundary condition is `slip`, `no slip` or
`wall function`. Use `no slip` only where the mesh resolves the viscous sublayer, and a wall function elsewhere. A wall
may also carry a [`velocity`](/reference/model/boundary-conditions/wall#velocity), a
[`roughness`](/reference/model/boundary-conditions/wall#roughness), a
[`temperature`](/reference/model/boundary-conditions/wall#temperature) and an FSI modal model,
[`fsi`](/reference/model/boundary-conditions/wall#fsi).

The best check of a mesh is a histogram of $y^{+}$ over the wall from a converged solution, plotted from the
[`yplus`](/reference/output-variables#yplus) surface output variable, which is written by default. $y^{+}$ scales
approximately linearly with the first cell height. If the histogram sits 2.5 times above the target, reduce the
first cell height by a factor of 2.5.

::: {.demo setting="reference/model/boundary-conditions/wall#kind" values="no slip, wall function" case="plate" figure="plate-wall-kind"}
![Velocity across the boundary layer of a flat plate in wall units, for a resolved wall and a wall function, against the linear sublayer and the log law](/images/plate-wall-kind.svg "A resolved wall carries the mesh into the viscous sublayer, where the profile follows the linear law before joining the log law. A wall function places its first cell in the log layer, at y+ ≈ 37, and applies the log law there. Above that cell the two profiles differ by at most 0.43 in u+. At this station the wall function gives a skin friction 2 per cent higher.")

Both runs use the Spalart–Allmaras model on meshes with the same number of cells. The wall-function mesh places its first cell a hundred times further from the wall.
:::

## Wall function

The law of the wall depends on the turbulence model. Menter SST uses Spalding's law, a single expression that spans
the viscous sublayer, the buffer layer and the log layer. SA-neg uses the Allmaras fit, which spans the same range;
with the incompressible law of the wall it is applied where the first cell lies below $y^+ = 200$, and above that the
log law alone is used. Because both laws hold through the sublayer, a wall-function wall tolerates a first cell
anywhere from $y^+ \sim 1$ into the log layer, so a mesh whose first-cell height varies along the wall needs no
switch between wall treatments. Even so, size the mesh for a first cell between $y^+ = 30$ and $250$.

By default a `'wall function'` wall uses an incompressible law of the wall. The velocity profile is solved with the
density and viscosity of the first cell off the wall, and no heat is transferred.

Giving the wall a [`temperature`](/reference/model/boundary-conditions/wall#temperature) or a
[`heat flux`](/reference/model/boundary-conditions/wall#heat-flux) switches it to the compressible wall function. This
is the Van Driest II / White–Christoph velocity transformation coupled to the Crocco–Busemann thermal law of the wall.
It evaluates $y^+$ and the wall shear stress with the density and viscosity of the wall state, and produces the wall
heat flux. With a `heat flux` the wall temperature is recovered; with a `temperature`, the heat flux. Both are
available as the `heatflux` and `twall` surface output variables.

The velocity transformation is worth having at speed whether or not the wall exchanges heat, since the boundary layer
of an adiabatic wall is still stratified by viscous heating.
[`compressible wall function`](/reference/model/boundary-conditions/wall#compressible-wall-function) runs it on an
adiabatic wall. The wall state is then evaluated at the recovery temperature $T_r$ rather than at a specified one, so
the wall heat flux is zero by construction:

```python
{
    "boundary_conditions": {
        "BC_2": {
            "zones": [2],
            "type": "wall",
            "kind": "wall function",
            "compressible wall function": True,
        },
    },
}
```

`twall` then reports $T_r$, and `heatflux` reports zero. The key is redundant alongside a `temperature` or a
`heat flux`, which select the same transformation and add the thermal closure to it.

A constant-heat-flux wall is singular where the boundary layer is thin, at a plate leading edge for example. The
modelled layer cannot carry an arbitrarily large flux there, and the wall temperature rises until it is limited
internally. Check the `twall` output if a prescribed flux is large.

::: {.demo setting="reference/model/boundary-conditions/wall#temperature" values="unset, 150 K" case="plate" figure="plate-wall-temperature"}
![Static temperature across the boundary layer of a flat plate at M = 0.2, for an adiabatic wall and a wall held at 150 K, against the adiabatic recovery temperature](/images/plate-wall-temperature.svg "The adiabatic wall's first cell sits at 301.6 K, 0.6 K below the recovery temperature of 302.2 K. The wall held at 150 K draws 28 kW/m² out of the layer, and its skin friction is 1.44 times the adiabatic wall's.")

Both runs use Menter SST with a wall function at M = 0.2 on the same mesh. Setting a wall temperature also selects the compressible wall function.
:::

::: {.demo setting="reference/model/boundary-conditions/wall#compressible-wall-function" values="false, true" case="plate" figure="plate-wall-compressible-wall-function"}
![Static temperature across the boundary layer of a flat plate at M = 2, for the incompressible and the compressible law of the wall, against the adiabatic recovery temperature](/images/plate-wall-compressible-wall-function.svg "Above the first cell the two profiles agree to within 0.3 K. The compressible law brings the wall to 519.7 K, 0.7 per cent above the recovery temperature of 516.0 K, with no heat flux; the incompressible law computes no wall temperature. The skin friction falls by 3.1 per cent.")

Both runs are adiabatic at M = 2, with Menter SST and a wall function on the same mesh.
:::

The compressible wall function, however it is selected, is not supported in the incompressible solver, and is rejected
at input validation.

### Rough compressible walls

[Roughness](#roughness) may be combined with the compressible wall function. This is the combination an icing
calculation needs. Ice accretion roughens the surface, which raises both the skin friction and the convective heat
transfer that in turn drives the accretion, while an ice protection system imposes a wall `heat flux` or
`temperature`. Both the roughness and the thermal state accept a `field`, so an ice roughness map and an
electrothermal pad layout can be prescribed face by face from VTP files. Each `field` is a path relative to the
directory zCFD is run from, and a deck whose file is missing or cannot be read is rejected at validation. A roughness
map must carry a point array named `Roughness`, and the solver stops at setup if any of its values is negative or not a
number.

The equivalent sand-grain height is given in mesh units, like every other length in the input deck. Nothing rescales
the mesh, so a 0.5 mm ice roughness on a mesh in metres is `0.0005`.

On the velocity side, the Van Driest transformed velocity obeys the incompressible rough-wall law, with the roughness
Reynolds number $k_s^+$ formed from the density and viscosity of the wall, not of the first cell. That is the scaling
the compressible wall function already uses for $y^+$ and the wall shear stress; on a heated, anti-iced wall the two
differ substantially.

On the thermal side, the Crocco–Busemann closure is an exact Reynolds analogy, so on its own it would raise the
Stanton number in the same ratio as the skin friction. Roughness elements shed momentum by pressure drag but carry
heat only by conduction, so in reality the heat transfer rises much less. The default
[`thermal model`](/reference/model/boundary-conditions/wall/roughness#thermal-model), `'owen thomson'`, therefore adds
a thermal sublayer resistance

$$
\Delta T^+ = 0.52 \, (k_s^+)^{0.45} \, Pr^{0.8}
$$

between the surface and the roughness crest. It is blended in over the same $k_s^+$ range as the velocity intercept,
so a hydraulically smooth wall is unaffected. Setting `thermal model` to `'reynolds analogy'` removes it.

On a rough wall the `twall` output is the temperature of the surface, not of the roughness crest on which the law of
the wall is closed; the two differ by the drop across that resistance. `heatflux` is continuous through it, and so is
unambiguous.

An anti-iced leading edge with a measured ice roughness map:

```python
{
    "boundary_conditions": {
        "BC_3": {
            "type": "wall",
            "kind": "wall function",
            "heat flux": {"field": "ips_pads.vtp"},
            "roughness": {"type": "height", "field": "ice_roughness.vtp"},
        },
    },
}
```

## Roughness

Roughness is applied by the wall-function treatment of both the compressible and the incompressible solver, for the
Menter SST and SA-neg turbulence models. On a `no slip` or `slip` wall it has no effect.

Internally the models work in equivalent sand-grain height, so a roughness given as a `length` is converted on input,
as `height = length / 0.03`. The `roughness` surface output variable reports that height, not the value written in the
deck.

::: {.demo setting="reference/model/boundary-conditions/wall#roughness" values="unset, height 0.001 m" case="plate" figure="plate-wall-roughness"}
![Velocity across the boundary layer of a flat plate in wall units, for a smooth wall and a wall with 1 mm sand-grain roughness, against the smooth log law and the fully rough log law](/images/plate-wall-roughness.svg "Roughness moves the whole log layer down. At a roughness Reynolds number of about 240 the rough profile lies on average 1.4 above Nikuradse's fully rough law in u+, where the smooth wall lies 0.7 above the smooth law. The skin friction is 1.84 times the smooth wall's.")

Both runs use Menter SST with a wall function on the same mesh; only the roughness differs.
:::

## Moving walls

[`velocity`](/reference/model/boundary-conditions/wall#velocity) applies a surface velocity, for surfaces in relative
motion: a car moving over a road surface, for example, or a rotating tyre. A rotating wall velocity takes an `axis`,
an `origin` and an `omega`, as a rotating frame does:

```python
"BC_3": {"type": "wall", "kind": "wall function", "zones": [14, 20],
         "velocity": {"type": "rotating", "axis": [0.0, -0.9988, 0.0498],
                      "origin": [0.0, -0.6593, 0.2533], "omega": 168.6}},
```

## Reference entries

- [`wall`](/reference/model/boundary-conditions/wall): [`kind`](/reference/model/boundary-conditions/wall#kind),
  [`temperature`](/reference/model/boundary-conditions/wall#temperature),
  [`heat flux`](/reference/model/boundary-conditions/wall#heat-flux),
  [`compressible wall function`](/reference/model/boundary-conditions/wall#compressible-wall-function),
  [`roughness`](/reference/model/boundary-conditions/wall#roughness),
  [`velocity`](/reference/model/boundary-conditions/wall#velocity) and
  [`fsi`](/reference/model/boundary-conditions/wall#fsi)
