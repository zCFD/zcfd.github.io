---
title: What is zCFD?
section: guide
group: Concepts
order: 10
---

# What is zCFD?

zCFD is a GPU-accelerated high-performance computational fluid dynamics (CFD) solver.

zCFD is designed to make highly effective use of modern computer architectures. It contains a high performance core, executed via a flexible Python based wrapper. zCFD will run on unstructured polyhedral meshes from a variety of sources, and will export data in VTK HDF format (.vtkhdf) for efficient post-processing with tools such as [ParaView](https://www.paraview.org/). zCFD offers an easier route to coupling multi-disciplinary capabilities and integrating third-party data sources.

Features include both compressible and incompressible finite-volume formulations, overset capability and fluid-structure interaction (FSI) running on both CPUs and GPUs. zCFD is capable of performing both steady-state and time accurate simulations, with a range of time marching schemes. The numerical schemes available have been selected for accuracy and reliability. The code provides automatic scaling of turbulent wall functions; automatic determination of inflow / outflow conditions and pre-conditioning to allow for low and high Mach number flow.

zCFD uses MPI to manage execution over multiple compute nodes. The execution process is completely parallel from the start to finish including all the input/output functionality. To support this scalable implementation the mesh input is provided in hdf5 format which is portable and self describing. Filters are provided to convert the most frequently used formats to this internal format.

zCFD uses a single control dictionary to specify all the parameters. This is a Python file containing a python dictionary with certain mandatory keys. The use of Python for the control dictionary enables the user to add custom functions that populate the dictionary at runtime.

The zCFD distribution also includes zm3, or zMesh-Cubed, the Zenotech Cartesian cut-cell mesh generator. This allows users to rapidly generate meshes for CFD from STL files, with minimal user cleanup effort required.
