import { renderToString } from "react-dom/server";
import { StaticRouter } from "react-router";
import { App, pageTitle } from "./components/App.jsx";
import { serverContent, site } from "./content.server.js";
import { leavesOf } from "./lib/nav.js";
import { routerPath } from "./lib/routes.js";

export { site };

export function render(route) {
  const content = serverContent();
  const leaves = leavesOf(site);
  const location =
    route === "/"
      ? "/index.html"
      : route === "/__not-found__"
        ? "/__not-found__"
        : routerPath(route);
  const html = renderToString(
    <StaticRouter location={location}>
      <App content={{ ...content, leaves }} />
    </StaticRouter>,
  );
  const leaf = leaves.get(route === "/" ? site.landing : route);
  return {
    html,
    title: pageTitle(site, route === "/__not-found__" ? null : leaf),
  };
}
