import { useNavigate } from "react-router-dom";
import { routerPath, splitHash } from "../lib/routes.js";
import { useContent } from "./context.js";

export function useDocNavigate() {
  const navigate = useNavigate();
  const c = useContent();
  return (to) => {
    const [route, hash] = splitHash(to);
    navigate(c.base + routerPath(route) + hash);
  };
}

export function DocLink({ to, children, onClick, ...rest }) {
  const go = useDocNavigate();
  const c = useContent();
  const handle = (e) => {
    if (onClick) onClick(e);
    if (
      e.defaultPrevented ||
      e.button !== 0 ||
      e.metaKey ||
      e.ctrlKey ||
      e.shiftKey ||
      e.altKey
    )
      return;
    e.preventDefault();
    go(to);
  };
  return (
    <a href={c.href(to)} onClick={handle} {...rest}>
      {children}
    </a>
  );
}
