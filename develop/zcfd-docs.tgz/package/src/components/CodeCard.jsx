import { useState } from "react";

export function CodeCard({ title, text, children, className = "" }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    const done = () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    };
    try {
      navigator.clipboard.writeText(text).then(done, () => {});
    } catch {
      setCopied(false);
    }
  };
  return (
    <div className={`codecard ${className}`}>
      <div className="cc-head">
        <span>{title}</span>
        <span className="spacer" />
        <button type="button" className="cc-copy" onClick={copy}>
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <div className="cc-body">{children}</div>
    </div>
  );
}
