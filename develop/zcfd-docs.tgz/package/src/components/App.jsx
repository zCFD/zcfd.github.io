import { Suspense, useContext, useEffect, useRef, useState } from "react";
import { Content, settle } from "./context.js";
import {
  Route,
  Routes,
  useHref,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { DocLink } from "./DocLink.jsx";
import { GuidePage } from "./GuidePage.jsx";
import { Reference } from "./Reference.jsx";
import { Search } from "./Search.jsx";
import { ThemeToggle } from "./Toggles.jsx";
import { Tree } from "./Tree.jsx";
import { Logo, Ico, ICONS } from "./Icons.jsx";
import {
  SECTIONS,
  ancestorsOf,
  firstRouteOf,
  leavesOf,
  sectionOf,
  treeFor,
} from "../lib/nav.js";
import {
  hrefOf,
  isExternal,
  normRoute,
  routeFromPathname,
  routerPath,
  splitHash,
} from "../lib/routes.js";
import { advanced, track, useHydrated } from "../lib/prefs.js";

export function crumbsFor(site, leaf) {
  if (!leaf) return [];
  const sec = SECTIONS.find((s) => s.id === sectionOf(leaf))?.label || "";
  if (leaf.kind === "reference")
    return [
      sec,
      ...ancestorsOf(site, leaf.route).map((a) => a.title),
      leaf.title,
    ];
  return [sec, leaf.group, leaf.title]
    .filter(Boolean)
    .filter((c, i, a) => a.indexOf(c) === i);
}

export function pageTitle(site, leaf) {
  return leaf ? `${leaf.title} · ${site.title}` : site.title;
}

function Leaf({ route }) {
  const c = useContext(Content);
  const leaf = c.leaves.get(route);
  const crumbs = crumbsFor(c.site, leaf);
  if (leaf.kind === "reference")
    return (
      <Reference
        page={settle(c.getReference(route))}
        site={c.site}
        crumbs={crumbs}
      />
    );
  return (
    <GuidePage leaf={leaf} body={settle(c.getPage(route))} crumbs={crumbs} />
  );
}

function NotFound() {
  const c = useContext(Content);
  return (
    <div className="pagehost guide">
      <h1 className="page-h1">Page not found</h1>
      <p className="lead">
        There is no page at this address in this release.{" "}
        <DocLink to={firstRouteOf(c.site, "guide")}>
          Start from the Guide
        </DocLink>
        , or search above.
      </p>
    </div>
  );
}

function useCurrentRoute() {
  const { pathname } = useLocation();
  const c = useContext(Content);
  const r = routeFromPathname(pathname, c.base);
  return r === "/" ? c.site.landing : r;
}

function Topbar({ section, onMenu }) {
  const c = useContext(Content);
  return (
    <header className="topbar">
      <button
        type="button"
        className="iconbtn round hamburger"
        aria-label="Show or hide navigation"
        onClick={onMenu}
      >
        <Ico d={ICONS.menu} />
      </button>
      {!c.embed && (
        <DocLink
          to={c.site.landing}
          className="brand"
          aria-label={`${c.site.title}, home`}
        >
          <Logo site={c.site} />
        </DocLink>
      )}
      <nav className="topnav" aria-label="Sections">
        {SECTIONS.map((s) => {
          const to = firstRouteOf(c.site, s.id);
          if (!to)
            return (
              <span key={s.id} className="topnav-off">
                {s.label}
              </span>
            );
          return (
            <DocLink
              key={s.id}
              to={to}
              className={s.id === section ? "on" : undefined}
            >
              {s.label}
            </DocLink>
          );
        })}
        {c.site.books.map((b) => (
          <a key={b.file} href={c.asset(b.file)}>
            {b.label}
          </a>
        ))}
      </nav>
      <span className="top-spacer" />
      <span
        className="ver-pill"
        title={`Documentation for ${c.site.product} ${c.site.version}`}
      >
        {c.site.version}
      </span>
      <Search indexUrl={c.searchIndexUrl} />
      {!c.embed && <ThemeToggle />}
    </header>
  );
}

function HashScroller({ route }) {
  const c = useContext(Content);
  const { hash, pathname } = useLocation();
  const navigate = useNavigate();
  const first = useRef(true);
  useEffect(() => {
    const leaf = c.leaves.get(route);
    if (leaf) document.title = pageTitle(c.site, leaf);
    const id = decodeURIComponent(hash.replace(/^#/, ""));
    if (!id) {
      if (!first.current) window.scrollTo(0, 0);
      first.current = false;
      return;
    }
    first.current = false;
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ block: "start" });
      return undefined;
    }
    const alias = (c.site.aliases || []).find(
      (a) =>
        a.field &&
        normRoute(a.from.split("#")[0]) === route &&
        a.from.split("#")[1] === id,
    );
    if (alias)
      navigate(c.base + routerPath(alias.route || route) + "#" + alias.field, {
        replace: true,
      });
    return undefined;
  }, [hash, pathname]);
  return null;
}

function Hydrated() {
  useEffect(() => {
    window.__zdocsHydrated = true;
  }, []);
  return null;
}

function Shell() {
  const c = useContext(Content);
  const route = useCurrentRoute();
  const leaf = c.leaves.get(route);
  const section = sectionOf(leaf);
  const [menu, setMenu] = useState(false);
  const hydrated = useHydrated();
  const heading =
    section === "reference"
      ? "Reference"
      : SECTIONS.find((s) => s.id === section)?.label;
  useEffect(() => {
    setMenu(false);
  }, [route]);
  const leafRoutes = [...c.leaves.keys()];
  return (
    <div className={`zdocs${hydrated && menu ? " menu-open" : ""}`}>
      <Topbar section={section} onMenu={() => setMenu(!menu)} />
      <div className="shell">
        <Tree
          nodes={treeFor(c.site, section)}
          current={route}
          heading={heading}
        />
        <main className="zmain" id="main">
          <Suspense fallback={<p className="loading">Loading…</p>}>
            <Routes>
              <Route path="/" element={<Leaf route={c.site.landing} />} />
              <Route
                path="/index.html"
                element={<Leaf route={c.site.landing} />}
              />
              {leafRoutes.map((r) => (
                <Route
                  key={r}
                  path={routerPath(r)}
                  element={<Leaf route={r} />}
                />
              ))}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </main>
      </div>
      <HashScroller route={route} />
      <Hydrated />
    </div>
  );
}

export function App({ content }) {
  const base = content.embed?.base || "";
  const assets = content.embed?.assets || "";
  const prefix = useHref(base || "/");
  useEffect(() => {
    if (!content.embed) return;
    track.sync();
    advanced.sync();
  }, [content.embed]);
  const value = {
    ...content,
    leaves: content.leaves || leavesOf(content.site),
    base,
    asset: (p) => (isExternal(p) || p.startsWith("data:") ? p : assets + p),
    href: content.embed
      ? (to) => {
          const [route, hash] = splitHash(to);
          return prefix + routerPath(route) + hash;
        }
      : hrefOf,
  };
  return (
    <Content.Provider value={value}>
      <Shell />
    </Content.Provider>
  );
}
