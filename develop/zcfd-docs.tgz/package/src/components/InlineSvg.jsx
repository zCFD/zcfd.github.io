import { settle, useContent } from "./context.js";

export function isThemedSvg(c, src) {
  return !!c?.site?.themedSvgs?.includes(src);
}

export function InlineSvg({ src, alt, title }) {
  const c = useContent();
  const svg = settle(c.getSvg(src));
  return (
    <span
      className="zc-figure zc-inline"
      role="img"
      aria-label={alt || undefined}
      title={title || undefined}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}
