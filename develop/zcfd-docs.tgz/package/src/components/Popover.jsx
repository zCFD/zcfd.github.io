import { cloneElement, useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";

export function HoverPopover({ content, children, delay = 350 }) {
  const [pos, setPos] = useState(null);
  const timer = useRef(null);
  const anchor = useRef(null);
  const id = useId();
  const clear = () => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  };
  const show = () => {
    clear();
    timer.current = setTimeout(() => {
      const el = anchor.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      setPos({
        left: r.left + window.scrollX,
        top: r.bottom + window.scrollY + 8,
      });
    }, delay);
  };
  const hide = () => {
    clear();
    setPos(null);
  };
  useEffect(() => {
    if (!pos) return undefined;
    window.addEventListener("scroll", hide, { passive: true, once: true });
    return () => window.removeEventListener("scroll", hide);
  }, [pos]);
  useEffect(() => clear, []);
  if (!content) return children;
  const child = cloneElement(children, {
    ref: anchor,
    "aria-describedby": pos ? id : undefined,
    onMouseEnter: show,
    onMouseLeave: hide,
    onFocus: show,
    onBlur: hide,
    onClick: (e) => {
      hide();
      children.props.onClick?.(e);
    },
  });
  return (
    <>
      {child}
      {pos &&
        createPortal(
          <div
            id={id}
            role="tooltip"
            className="popover bs-popover-bottom zdocs-popover"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              transform: `translate(${Math.round(pos.left)}px, ${Math.round(pos.top)}px)`,
            }}
          >
            <div
              className="popover-arrow"
              style={{ position: "absolute", left: "1rem" }}
            />
            <div className="popover-body">{content}</div>
          </div>,
          document.body,
        )}
    </>
  );
}
