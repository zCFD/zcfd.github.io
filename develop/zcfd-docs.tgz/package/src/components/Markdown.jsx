import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import remarkDirective from "remark-directive";
import rehypeKatex from "rehype-katex";
import {
  demoSetting,
  normalisePandocDivs,
  remarkZdocsDirectives,
  rehypeFigures,
  rehypeHeadingIds,
} from "../lib/directives.js";
import { assetPath, resolveLink } from "../lib/routes.js";
import { slug } from "../lib/slug.js";
import { DocLink } from "./DocLink.jsx";
import { TrackSwitch } from "./Toggles.jsx";
import { useContent } from "./context.js";
import { CodeCard } from "./CodeCard.jsx";
import { Ico, ICONS } from "./Icons.jsx";
import { InlineSvg, isThemedSvg } from "./InlineSvg.jsx";

export const REMARK_PLUGINS = [
  remarkGfm,
  remarkMath,
  remarkDirective,
  remarkZdocsDirectives,
];
const REHYPE_PLUGINS = [
  [rehypeHeadingIds, { slug }],
  rehypeKatex,
  rehypeFigures,
];

const prop = (node, k) => node?.properties?.[k];

function textOf(children) {
  if (typeof children === "string") return children;
  if (Array.isArray(children)) return children.map(textOf).join("");
  if (children && children.props) return textOf(children.props.children);
  return "";
}

export function Markdown({ body, sourcePath, route, className }) {
  const c = useContent();
  const components = {
    a: ({ href = "", children, node, ...rest }) => {
      const r = resolveLink(sourcePath, route, href);
      if (r.external)
        return (
          <a href={r.href} {...rest}>
            {children}
          </a>
        );
      if (r.asset)
        return (
          <a href={c.asset(r.asset)} {...rest}>
            {children}
          </a>
        );
      return (
        <DocLink to={r.to} {...rest}>
          {children}
        </DocLink>
      );
    },
    img: ({ src = "", alt = "", title, node, ...rest }) => {
      const path = assetPath(sourcePath, src);
      if (isThemedSvg(c, path))
        return <InlineSvg src={path} alt={alt} title={title} />;
      return (
        <img
          src={c.asset(path)}
          alt={alt}
          title={title}
          loading="lazy"
          {...rest}
        />
      );
    },
    table: ({ children, node, ...rest }) => (
      <div className="ntable-scroll">
        <table className="gtable" {...rest}>
          {children}
        </table>
      </div>
    ),
    "zdocs-admonition": ({ node, children }) => {
      const kind = prop(node, "kind") === "warning" ? "warning" : "note";
      return (
        <aside className={`admon admon-${kind}`}>
          <div className="admon-h">
            <Ico d={kind === "warning" ? ICONS.warn : ICONS.info} />
            {kind === "warning" ? "Warning" : "Note"}
          </div>
          <div className="admon-b">{children}</div>
        </aside>
      );
    },
    "zdocs-track-switch": ({ children }) => (
      <TrackSwitch>{children}</TrackSwitch>
    ),
    "zdocs-track": ({ node, children }) => (
      <div className="track" data-when={prop(node, "when")}>
        {children}
      </div>
    ),
    "zdocs-deck": function Deck({ node, children }) {
      const { site } = useContent();
      return (
        <CodeCard
          title={prop(node, "title") || site.settingsFile || "settings"}
          text={textOf(children)}
        >
          {children}
        </CodeCard>
      );
    },
    "zdocs-demo": ({ node, children }) => {
      const setting = demoSetting(prop(node, "setting"));
      const name = setting.to ? (
        <DocLink to={setting.to}>
          <code>{setting.label}</code>
        </DocLink>
      ) : (
        <code>{setting.label}</code>
      );
      return (
        <figure
          className="demo zc-figure"
          data-setting={prop(node, "setting")}
          data-case={prop(node, "case")}
        >
          <div className="demo-cap">
            Demonstration: what {name} does{" "}
            <span className="tag real">From the {prop(node, "case")} case</span>
          </div>
          <div className="demo-body-md">{children}</div>
          <div className="dv-prov">
            <span>setting {name}</span>
            <span>
              values <b>{prop(node, "values")}</b>
            </span>
            <span>
              case <b>{prop(node, "case")}</b>
            </span>
          </div>
        </figure>
      );
    },
  };
  const md = (
    <ReactMarkdown
      remarkPlugins={REMARK_PLUGINS}
      rehypePlugins={REHYPE_PLUGINS}
      components={components}
    >
      {normalisePandocDivs(body)}
    </ReactMarkdown>
  );
  return className ? <div className={className}>{md}</div> : md;
}
