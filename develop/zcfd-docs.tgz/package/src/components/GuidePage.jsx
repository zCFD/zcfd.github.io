import { useEffect, useRef } from "react";
import { Markdown } from "./Markdown.jsx";
import { DocLink } from "./DocLink.jsx";
import { useContent } from "./context.js";
import { headingsOf } from "../lib/directives.js";
import { mountLiveDeck } from "../lib/liveDeck.js";
import { slug } from "../lib/slug.js";

export function GuidePage({ leaf, body, crumbs }) {
  const toc = headingsOf(body, slug).filter((h) => h.depth === 2);
  const content = useContent();
  const host = useRef(null);
  const rail = useRef(null);
  useEffect(() => {
    if (!leaf.decks || !content.getDecks) return;
    let live = null;
    let gone = false;
    Promise.resolve(content.getDecks(leaf.route)).then((decks) => {
      if (gone || !decks?.length) return;
      live = mountLiveDeck(host.current, rail.current, decks, (id) =>
        content.href(`${leaf.route}#${id}`),
      );
    });
    return () => {
      gone = true;
      live?.destroy();
    };
  }, [leaf.route, leaf.decks, body]);
  return (
    <div className="pagehost guide" data-section={leaf.section} ref={host}>
      <div className="crumb">
        {crumbs.map((c, i) => (
          <span key={i}>
            {i > 0 && " / "}
            {i === crumbs.length - 1 ? <b>{c}</b> : c}
          </span>
        ))}
      </div>
      <div className="guidewrap">
        <article className="guidedoc">
          <Markdown body={body} sourcePath={leaf.source} route={leaf.route} />
        </article>
        {toc.length > 1 && (
          <nav className="guide-toc" aria-label="On this page">
            <div className="toc-lab">On this page</div>
            {toc.map((h) => (
              <DocLink key={h.id} to={`${leaf.route}#${h.id}`}>
                {h.text}
              </DocLink>
            ))}
          </nav>
        )}
        {leaf.decks && <div className="rail" ref={rail} />}
      </div>
    </div>
  );
}
