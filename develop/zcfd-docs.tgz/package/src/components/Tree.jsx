import { useEffect, useState } from "react";
import { DocLink } from "./DocLink.jsx";
import { pathTo } from "../lib/nav.js";

const OPENED = "zdocs.tree";

function readOpened() {
  try {
    const v = JSON.parse(window.localStorage.getItem(OPENED) || "[]");
    return new Set(Array.isArray(v) ? v : []);
  } catch {
    return new Set();
  }
}

function saveOpened(set) {
  try {
    window.localStorage.setItem(OPENED, JSON.stringify([...set]));
  } catch {
    return;
  }
}

function flip(set, route) {
  const next = new Set(set);
  if (!next.delete(route)) next.add(route);
  return next;
}

function Indent({ trail, last }) {
  return (
    <>
      {trail.map((passes, i) => (
        <span key={i} className={passes ? "tind" : "tind blank"} />
      ))}
      <span className={last ? "tind conn" : "tind conn mid"} />
    </>
  );
}

function rows(nodes, trail, fold, out) {
  nodes.forEach((n, i) => {
    const last = i === nodes.length - 1;
    const here = n.route && n.route === fold.current;
    const branch = n.children?.length > 0;
    const open = branch && fold.isOpen(n);
    const label = (
      <span className={branch ? "tlab" : "tlab dim"}>{n.label}</span>
    );
    out.push(
      <div
        key={n.route || `${n.label}-${i}`}
        className={`trow${here ? " sel" : ""}${n.mono ? " mono-row" : ""}`}
      >
        <Indent trail={trail} last={last} />
        {branch && (
          <button
            type="button"
            className={`tchev${open ? " open" : ""}`}
            aria-expanded={open}
            aria-label={`${open ? "Close" : "Open"} ${n.label}`}
            onClick={() => fold.toggle(n)}
          >
            ›
          </button>
        )}
        {n.route ? (
          <DocLink
            to={n.route}
            className="tlink"
            aria-current={here ? "page" : undefined}
          >
            {label}
          </DocLink>
        ) : (
          label
        )}
      </div>,
    );
    if (open) rows(n.children, [...trail, !last], fold, out);
  });
  return out;
}

export function Tree({ nodes, current, heading }) {
  const [opened, setOpened] = useState(() => new Set());
  const [shut, setShut] = useState(() => new Set());
  useEffect(() => setOpened(readOpened()), []);
  useEffect(() => setShut(new Set()), [current]);
  const path = new Set(pathTo(nodes, current));
  const fold = {
    current,
    isOpen: (n) =>
      path.has(n.route) ? !shut.has(n.route) : opened.has(n.route),
    toggle: (n) => {
      if (path.has(n.route)) return setShut(flip(shut, n.route));
      const next = flip(opened, n.route);
      saveOpened(next);
      setOpened(next);
    },
  };
  const out = [];
  nodes.forEach((sec, i) => {
    out.push(
      sec.route ? (
        <DocLink
          key={`s-${i}`}
          to={sec.route}
          className={`tsec${sec.route === current ? " sel" : ""}`}
          aria-current={sec.route === current ? "page" : undefined}
        >
          {sec.label}
        </DocLink>
      ) : (
        <div key={`s-${i}`} className="tsec">
          {sec.label}
        </div>
      ),
    );
    rows(sec.children || [], [], fold, out);
  });
  return (
    <aside className="vc-tree" aria-label={heading}>
      <div className="vc-tree-head">
        <svg className="ico" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 3l9 9-9 9-9-9z" />
        </svg>
        {heading}
      </div>
      <nav className="tree-body">{out}</nav>
    </aside>
  );
}
