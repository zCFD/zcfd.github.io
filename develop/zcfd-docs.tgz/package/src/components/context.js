import { createContext, use, useContext } from "react";

export const Content = createContext(null);
export const settle = (v) => (v && typeof v.then === "function" ? use(v) : v);
export const useContent = () => useContext(Content);
