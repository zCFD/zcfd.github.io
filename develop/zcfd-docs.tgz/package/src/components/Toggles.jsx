import { theme, track, advanced } from "../lib/prefs.js";
import { Ico, ICONS } from "./Icons.jsx";

const THEMES = [
  { v: "light", label: "Light", icon: ICONS.sun },
  { v: "system", label: "Follow the system", icon: ICONS.auto },
  { v: "dark", label: "Dark", icon: ICONS.moon },
];

export function ThemeToggle() {
  const v = theme.use();
  return (
    <div className="seg theme-toggle" role="group" aria-label="Theme">
      {THEMES.map((t) => (
        <button
          key={t.v}
          type="button"
          data-v={t.v}
          aria-pressed={v === t.v}
          aria-label={t.label}
          onClick={() => theme.set(t.v)}
        >
          <Ico d={t.icon} />
        </button>
      ))}
    </div>
  );
}

export function TrackSwitch({ children }) {
  const v = track.use();
  return (
    <div className="track-switch">
      <div className="seg track-tabs" role="group" aria-label="Track">
        <button
          type="button"
          data-v="zui"
          aria-pressed={v === "zui"}
          onClick={() => track.set("zui")}
        >
          In zui
        </button>
        <button
          type="button"
          data-v="deck"
          aria-pressed={v === "deck"}
          onClick={() => track.set("deck")}
        >
          In the deck
        </button>
      </div>
      {children}
    </div>
  );
}

export function AdvancedToggle() {
  const v = advanced.use();
  return (
    <button
      type="button"
      className="iconbtn accent advalways"
      aria-pressed={v === "show"}
      onClick={() => advanced.set(v === "show" ? "hide" : "show")}
    >
      <Ico d={ICONS.eye} />
      <span className="btxt">Always show advanced</span>
    </button>
  );
}
