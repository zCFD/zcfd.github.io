export function Logo({ site }) {
  if (!site.logo) return <span className="brand-name">{site.product}</span>;
  return (
    <span
      role="img"
      aria-label={site.product}
      dangerouslySetInnerHTML={{ __html: site.logo }}
    />
  );
}

export function Ico({ d, className = "" }) {
  return (
    <svg className={`ico ${className}`} viewBox="0 0 24 24" aria-hidden="true">
      {[].concat(d).map((p, i) => (
        <path key={i} d={p} />
      ))}
    </svg>
  );
}

export const ICONS = {
  diamond: "M12 3l9 9-9 9-9-9z",
  search: ["M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14z", "M21 21l-4.3-4.3"],
  sun: [
    "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
    "M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4",
  ],
  moon: "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z",
  auto: ["M12 3a9 9 0 1 0 0 18z", "M12 3a9 9 0 0 1 0 18"],
  info: ["M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z", "M12 8h.01M11 12h1v4h1"],
  warn: ["M12 3l10 18H2z", "M12 10v4M12 17h.01"],
  code: ["M8 6l-6 6 6 6", "M16 6l6 6-6 6"],
  menu: "M4 6h16M4 12h16M4 18h16",
  list: "M4 7h16M4 12h16M4 17h10",
  eye: [
    "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z",
    "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
  ],
};
