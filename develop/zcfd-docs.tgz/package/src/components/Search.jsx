import { useRef, useState } from "react";
import { SEARCH_OPTIONS } from "../lib/searchOptions.js";
import { useDocNavigate } from "./DocLink.jsx";
import { useContent } from "./context.js";
import { Ico, ICONS } from "./Icons.jsx";

export function Search({ indexUrl }) {
  const [q, setQ] = useState("");
  const [ms, setMs] = useState(null);
  const [err, setErr] = useState(null);
  const [active, setActive] = useState(0);
  const loading = useRef(null);
  const go = useDocNavigate();
  const c = useContent();

  const load = () => {
    if (loading.current) return;
    const url = typeof indexUrl === "function" ? indexUrl() : indexUrl;
    loading.current = Promise.all([
      import("minisearch"),
      Promise.resolve(url)
        .then((u) => fetch(u))
        .then((r) => {
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          return r.text();
        }),
    ])
      .then(([{ default: MiniSearch }, json]) =>
        setMs(MiniSearch.loadJSON(json, SEARCH_OPTIONS)),
      )
      .catch((e) => setErr(String(e.message || e)));
  };

  const results = ms && q.trim().length > 1 ? ms.search(q).slice(0, 12) : [];
  const target = (r) => r.route + (r.anchor ? "#" + r.anchor : "");
  const pick = (r) => {
    setQ("");
    go(target(r));
  };

  return (
    <div className="searchwrap">
      <div className="searchbox">
        <input
          type="search"
          placeholder="Search the docs"
          aria-label="Search the docs"
          value={q}
          onFocus={load}
          onChange={(e) => {
            setQ(e.target.value);
            setActive(0);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActive((a) => Math.min(a + 1, results.length - 1));
            }
            if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((a) => Math.max(a - 1, 0));
            }
            if (e.key === "Enter" && results[active]) pick(results[active]);
            if (e.key === "Escape") setQ("");
          }}
        />
        <button
          type="button"
          aria-label="Search"
          onClick={() => results[active] && pick(results[active])}
        >
          <Ico d={ICONS.search} />
        </button>
      </div>
      {err && <p className="search-err">Search is unavailable: {err}</p>}
      {results.length > 0 && (
        <ul
          className="search-results"
          role="listbox"
          aria-label="Search results"
        >
          {results.map((r, i) => (
            <li
              key={r.id}
              role="option"
              aria-selected={i === active}
              className={i === active ? "on" : undefined}
            >
              <a
                href={c.href(target(r))}
                onMouseDown={(e) => {
                  e.preventDefault();
                  pick(r);
                }}
              >
                <span className="r-title">{r.title}</span>
                {r.kind === "field" && r.name && <code>{r.name}</code>}
                <span className="r-parent">{r.parent}</span>
              </a>
            </li>
          ))}
        </ul>
      )}
      {ms && q.trim().length > 1 && results.length === 0 && (
        <p className="search-err">Nothing matches that.</p>
      )}
    </div>
  );
}
