import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { useContent } from "./context.js";
import { DocLink } from "./DocLink.jsx";
import { HoverPopover } from "./Popover.jsx";
import { AdvancedToggle } from "./Toggles.jsx";
import { CodeCard } from "./CodeCard.jsx";
import { useHydrated } from "../lib/prefs.js";
import {
  blockDefault,
  blockText,
  displayKey,
  factsParts,
  findByAnchor,
  isFixedDiscriminator,
  optionOnly,
  outlineLines,
  outlineText,
  plainValue,
  titleAdds,
  variableContext,
  variableGroups,
  variantLabel,
} from "../lib/entry.js";
import { normRoute, splitHash } from "../lib/routes.js";
import { Markdown } from "./Markdown.jsx";
import { InlineSvg } from "./InlineSvg.jsx";

function Chips({ e, page, brief }) {
  const only = brief ? null : variantLabel(page, e.variants);
  return (
    <>
      {e.facts?.required && <span className="chip chip-req">required</span>}
      {e.facts?.advanced && <span className="chip chip-adv">advanced</span>}
      {only && <span className="chip chip-kind">{only}</span>}
    </>
  );
}

function FactsStrip({ e, site }) {
  const parts = factsParts(e);
  const fnPage = site.pages.find((p) => /python functions/i.test(p.title));
  return (
    <div className="facts-strip">
      {parts.map((p, i) => (
        <span key={i}>
          {i > 0 && <span className="fsep">·</span>}
          {p.python && fnPage ? (
            <DocLink
              to={fnPage.route}
              className={`fk${p.cls ? " " + p.cls : ""}`}
            >
              {p.text}
            </DocLink>
          ) : (
            <span className={`fk${p.cls ? " " + p.cls : ""}`}>{p.text}</span>
          )}
        </span>
      ))}
    </div>
  );
}

export function Prose({ text }) {
  const parts = String(text).split(/(`[^`]+`)/g);
  return parts.map((p, i) =>
    p.length > 2 && p.startsWith("`") && p.endsWith("`") ? (
      <code key={i}>{p.slice(1, -1)}</code>
    ) : (
      p
    ),
  );
}

const described = (e) => !!e.description && !e.gap;

function EntryText({ text, route, brief }) {
  const { site } = useContent();
  if (site.descriptions !== "markdown") return <Prose text={text} />;
  return (
    <SideText text={brief ? text.split(/\n\s*\n/)[0] : text} route={route} />
  );
}

function Description({ e, route }) {
  const { site } = useContent();
  if (!described(e)) return null;
  if (site.descriptions === "markdown")
    return (
      <div className="desc">
        <SideText text={e.description} route={route} />
      </div>
    );
  return (
    <p className="desc">
      <Prose text={e.description} />
    </p>
  );
}

function DefaultBlock({ e }) {
  const value = blockDefault(e);
  if (!value) return null;
  return (
    <div className="default-block">
      <span className="default-lab">Default</span>
      <pre>
        <code>{highlight(blockText(value, e.fields))}</code>
      </pre>
    </div>
  );
}

function SideText({ text, route }) {
  if (!text) return null;
  return (
    <Markdown
      body={text}
      sourcePath={route.slice(1) + ".md"}
      route={route}
      className="md-cell"
    />
  );
}

function OptionsTable({ e, page, label }) {
  if (!e.options?.length) return null;
  const anyWhen = e.options.some((o) => o.when);
  return (
    <div className="optsblock">
      <div className="opts-head">
        <span className="opts-lab">
          Options
          {label && (
            <>
              {" "}
              · <span className="mono">{label}</span>
            </>
          )}
        </span>
      </div>
      <div className="ntable-scroll">
        <table className="otable">
          <thead>
            <tr>
              <th>Value</th>
              <th>What it does</th>
              {anyWhen && <th>When to use it</th>}
            </tr>
          </thead>
          <tbody>
            {e.options.map((o) => {
              const only = optionOnly(page, o);
              return (
                <tr key={JSON.stringify(o.value)}>
                  <td className="ov">
                    <span className="pchip">{plainValue(o.value)}</span>
                    {o.default && (
                      <>
                        {" "}
                        <span className="chip opts-def">default</span>
                      </>
                    )}
                    {only && (
                      <div>
                        <span className="chip chip-kind">{only}</span>
                      </div>
                    )}
                  </td>
                  <td>
                    <SideText text={o.what} route={page.route} />
                  </td>
                  {anyWhen && (
                    <td>
                      <SideText text={o.when} route={page.route} />
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Demo({ e, site }) {
  const c = useContent();
  if (!e.demo) return null;
  const d = site.demos?.[e.demo];
  const src =
    d?.src ||
    (site.images || []).find(
      (p) =>
        p.replace(/^images\//, "").replace(/\.(svg|png|jpe?g)$/i, "") ===
        e.demo,
    );
  if (!src) return null;
  const themed = site.themedSvgs?.includes(src);
  const art = themed ? (
    <InlineSvg src={src} alt={d?.caption} />
  ) : (
    <img src={c.asset(src)} alt={d?.caption || ""} />
  );
  return (
    <figure className="demo zc-figure" data-figure={e.demo}>
      <div className="demo-cap">
        Demonstration: what <b>{d?.setting || displayKey(e)}</b> does{" "}
        {d?.case && <span className="tag real">From the {d.case} case</span>}
      </div>
      {d?.hover ? (
        <HoverPopover content={d.hover}>
          <div className="zc-figure-art" tabIndex={0}>
            {art}
          </div>
        </HoverPopover>
      ) : (
        <div className="zc-figure-art">{art}</div>
      )}
      {d?.caption && <figcaption>{d.caption}</figcaption>}
      {d?.body && <p className="demo-body">{d.body}</p>}
      {d && (
        <div className="dv-prov">
          <span>
            setting <b>{d.setting}</b>
          </span>
          <span>
            values <b>{d.values}</b>
          </span>
          <span>
            case <b>{d.case}</b>
          </span>
        </div>
      )}
    </figure>
  );
}

function UsedIn({ e }) {
  if (e.widely_used) return null;
  const cases = [
    ...new Set((e.examples || []).map((x) => x?.source?.case).filter(Boolean)),
  ];
  if (!cases.length) return null;
  return (
    <div className="usedrow">
      <span className="lead-in">Used in</span>
      {cases.map((c) => (
        <span key={c} className="case">
          {c}
        </span>
      ))}
    </div>
  );
}

function GuideLink({ e, site }) {
  if (!e.guide) return null;
  const [route, hash] = e.guide.split("#");
  const page = site.pages.find((p) => p.route === normRoute(route));
  return (
    <DocLink
      to={normRoute(route) + (hash ? "#" + hash : "")}
      className="guidelink"
    >
      <span className="gl-lead">Guidance:</span> {page ? page.title : route} →
    </DocLink>
  );
}

function AnchorButton({ to }) {
  const c = useContent();
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const ref = useRef(null);
  const url = open ? new URL(c.href(to), document.baseURI).href : "";
  useEffect(() => {
    if (!open) return undefined;
    const close = (ev) => {
      if (ref.current && !ref.current.contains(ev.target)) setOpen(false);
    };
    const esc = (ev) => {
      if (ev.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);
  const copy = () => {
    try {
      navigator.clipboard.writeText(url).then(
        () => setCopied(true),
        () => {},
      );
    } catch {
      setCopied(false);
    }
  };
  return (
    <span className="anchor-wrap" ref={ref}>
      <button
        type="button"
        className="anchor-btn"
        aria-label="Link to this entry"
        aria-expanded={open}
        onClick={() => {
          setCopied(false);
          setOpen(!open);
        }}
      >
        <svg className="ico" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M10 13a5 5 0 0 0 7.1 0l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7" />
          <path d="M14 11a5 5 0 0 0-7.1 0l-3 3a5 5 0 0 0 7.1 7.1l1.7-1.7" />
        </svg>
      </button>
      {open && (
        <span
          className="popover bs-popover-bottom zdocs-popover anchor-pop"
          role="dialog"
          aria-label="Link to this entry"
        >
          <span className="popover-arrow" />
          <span className="popover-body">
            <span className="zpop-h">Link to this entry</span>
            <code className="zpop-path">{url}</code>
            <button type="button" className="zpop-btn" onClick={copy}>
              {copied ? "Copied" : "Copy link"}
            </button>
          </span>
        </span>
      )}
    </span>
  );
}

function EntryDetail({ e, page, site, on }) {
  return (
    <section
      id={e.anchor}
      className={`detail-sec${on ? " on" : ""}`}
      aria-labelledby={`${e.anchor}-h`}
    >
      <div className="detail-h" id={`${e.anchor}-h`}>
        <span className="mono">{displayKey(e)}</span>
        {titleAdds(e) && (
          <>
            {" "}
            <span className="plain">{e.title}</span>
          </>
        )}
        <Chips e={e} page={page} />
        <AnchorButton to={`${page.route}#${e.anchor}`} />
      </div>
      <FactsStrip e={e} site={site} />
      <Description e={e} route={page.route} />
      <DefaultBlock e={e} />
      <OptionsTable e={e} page={page} />
      <Demo e={e} site={site} />
      <UsedIn e={e} />
      <GuideLink e={e} site={site} />
    </section>
  );
}

function MasterItem({ e, route, sel, page }) {
  const link = (
    <DocLink
      to={e.link ? normRoute(e.link) : `${route}#${e.anchor}`}
      id={e.link ? e.anchor : undefined}
      className={`mitem${sel ? " sel" : ""}${e.facts?.advanced ? " adv" : ""}${e.link ? " mdeep" : ""}`}
      aria-current={sel ? "true" : undefined}
    >
      <span className="pchip">{displayKey(e)}</span>
      {titleAdds(e) && <span className="mi-plain">{e.title}</span>}
      <Chips e={e} page={page} brief />
      {e.facts?.overridable_per_model && (
        <span className="chip chip-kind">a mesh may set its own</span>
      )}
      {e.link && (
        <span className="mi-deep" aria-label="opens its own page">
          ›
        </span>
      )}
    </DocLink>
  );
  if (!described(e)) return link;
  return (
    <HoverPopover
      content={<EntryText text={e.description} route={route} brief />}
    >
      {link}
    </HoverPopover>
  );
}

function linkOf(page, e) {
  return e.link ? e.link : `${page.route.replace(/^\//, "")}#${e.anchor}`;
}

function docTarget(link) {
  const [route, hash] = splitHash(link);
  return normRoute(route) + hash;
}

function OutlineKey({ line }) {
  const key = <span className="tk-key">{line.key}</span>;
  if (!line.link) return key;
  return (
    <DocLink to={docTarget(line.link)} className="pykey">
      {key}
    </DocLink>
  );
}

function OutlineValue({ line }) {
  if (line.muted) return <span className="pymut">{line.value}</span>;
  return highlight(line.value);
}

const LANGUAGE_NAMES = { python: "Python", json: "JSON" };

export function DeckOutline({ outline, selected, title }) {
  const { site } = useContent();
  if (!outline) return null;
  const language = site.settingsLanguage || "json";
  const lines = outlineLines(outline, language);
  return (
    <CodeCard
      title={title || site.settingsFile || "settings"}
      text={outlineText(outline, language)}
    >
      {lines.map((l, i) => (
        <div
          key={i}
          className={`pyln${selected && l.link === selected ? " hilite" : ""}`}
        >
          {l.pad}
          {l.close ? (
            (l.list ? "]" : "}") + l.tail
          ) : l.root ? (
            l.text
          ) : (
            <>
              {l.key && (
                <>
                  <OutlineKey line={l} />:{" "}
                </>
              )}
              {l.open ? l.list ? "[" : "{" : <OutlineValue line={l} />}
              {l.open ? "" : l.tail}
            </>
          )}
        </div>
      ))}
    </CodeCard>
  );
}

function highlight(text) {
  const out = [];
  const re =
    /("(?:[^"\\]|\\.)*")(\s*:)?|\b(True|False|None|true|false|null)\b|(-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b)/g;
  let last = 0;
  let m;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    if (m[1])
      out.push(
        <span key={i++} className={m[2] ? "tk-key" : "tk-s"}>
          {m[1]}
        </span>,
        m[2] || "",
      );
    else if (m[3])
      out.push(
        <span key={i++} className="tk-k">
          {m[3]}
        </span>,
      );
    else
      out.push(
        <span key={i++} className="tk-n">
          {m[4]}
        </span>,
      );
    last = re.lastIndex;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function useSelection(entries) {
  const hydrated = useHydrated();
  const { hash } = useLocation();
  const anchor = hydrated ? decodeURIComponent(hash.replace(/^#/, "")) : "";
  const hit = anchor ? findByAnchor(entries, anchor) : null;
  const top = hit ? hit.parents[0] || hit.entry : entries[0] || null;
  return { anchor, hit, top };
}

function MasterDetail({ page, site, entries }) {
  const keyed = entries.filter((e) => !e.link);
  const { anchor, hit, top } = useSelection(keyed);
  const [advOpen, setAdvOpen] = useState(false);
  const basic = entries.filter((e) => !e.facts?.advanced);
  const adv = entries.filter((e) => e.facts?.advanced);
  const open = advOpen || !!(top && top.facts?.advanced);
  useEffect(() => {
    if (!hit) return;
    const el = document.getElementById(hit.entry.anchor);
    if (el && hit.parents.length) el.scrollIntoView({ block: "center" });
  }, [anchor]);
  return (
    <div className="r-grid">
      <div
        className={`mlist${open ? " adv-open" : ""}`}
        aria-label="Parameters"
      >
        {basic.map((e) => (
          <MasterItem
            key={e.anchor}
            e={e}
            route={page.route}
            sel={e === top}
            page={page}
          />
        ))}
        {adv.length > 0 && (
          <button
            type="button"
            className="adv-grouphdr"
            aria-expanded={open}
            onClick={() => setAdvOpen(!open)}
          >
            <span className="agh-mark agh-closed">▸</span>
            <span className="agh-mark agh-open">▾</span>Advanced ({adv.length})
            <span className="agh-always">always shown</span>
          </button>
        )}
        {adv.map((e) => (
          <MasterItem
            key={e.anchor}
            e={e}
            route={page.route}
            sel={e === top}
            page={page}
          />
        ))}
      </div>
      <div className="detail">
        {keyed.map((e) => (
          <EntryDetail
            key={e.anchor}
            e={e}
            page={page}
            site={site}
            on={e === top}
          />
        ))}
      </div>
    </div>
  );
}

function Walkthrough({ w }) {
  if (!w) return null;
  return (
    <section className="walkthrough" aria-labelledby="a-minimal-deck">
      <h2 id="a-minimal-deck">A minimal deck</h2>
      <p>
        The keys every deck must set, with one boundary condition and one fluid
        zone. Each key links to its entry. Names in angle brackets are chosen by
        the deck, and <code>...</code> marks optional keys left out.
      </p>
      <DeckOutline outline={w.deck} />
      <dl className="walk-blocks">
        {w.blocks.map((b) => (
          <div key={b.key}>
            <dt>
              <DocLink to={docTarget(b.link)}>{b.key}</DocLink>
            </dt>
            <dd>
              <Prose text={b.text} />
            </dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

function TypePills({ site, route }) {
  const me = site.reference.find((r) => r.route === route);
  const parent = me?.kind === "type" ? me.parent : route;
  const types = site.reference
    .filter((r) => r.parent === parent && r.kind === "type")
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  if (!types.length) return null;
  const label = site.reference.find((r) => r.route === parent)?.title || "Type";
  return (
    <div className="pillbar" role="navigation" aria-label={`${label} types`}>
      <span className="pill-lab">Type</span>
      {types.map((t) => (
        <DocLink
          key={t.route}
          to={t.route}
          className={`pill${t.route === route ? " on" : ""}`}
        >
          {t.title}
        </DocLink>
      ))}
    </div>
  );
}

const VARIABLE_FILTERS = [
  { id: "all", label: "All" },
  { id: "volume", label: "Volume" },
  { id: "surface", label: "Surface" },
];

function OutputVariables({ page }) {
  const [filter, setFilter] = useState("all");
  const groups = variableGroups(page.entries, filter);
  return (
    <>
      <div className="ov-filter" role="radiogroup" aria-label="Written to">
        <span className="ov-filter-lab">Written to</span>
        {VARIABLE_FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            role="radio"
            aria-checked={filter === f.id}
            className={`pill${filter === f.id ? " on" : ""}`}
            onClick={() => setFilter(f.id)}
          >
            {f.label}
          </button>
        ))}
      </div>
      {groups.map((g) => (
        <section key={g.id} className="ov-group" aria-labelledby={g.id}>
          <h2 id={g.id}>{g.label}</h2>
          {g.hint && <p className="ov-hint">{g.hint}.</p>}
          <div className="ntable-scroll">
            <table className="gtable reftable ov-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>What it is</th>
                  <th>Written to</th>
                  <th>Also accepted as</th>
                </tr>
              </thead>
              <tbody>
                {g.entries.map((e) => (
                  <tr key={e.anchor} id={e.anchor}>
                    <td className="gk">
                      <code>{e.key}</code>
                    </td>
                    <td>
                      {described(e) && <Prose text={e.description} />}
                      {e.pattern && (
                        <div className="ov-pattern">
                          <Prose text={e.pattern} />
                        </div>
                      )}
                    </td>
                    <td className="ov-context">{variableContext(e)}</td>
                    <td className="gyp">
                      {(e.aliases || []).map((a, i) => (
                        <span key={a}>
                          {i > 0 && ", "}
                          <code>{a}</code>
                        </span>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ))}
    </>
  );
}

export function Reference({ page, site, crumbs }) {
  const route = normRoute(page.route);
  const p = { ...page, route };
  const entries = (page.entries || []).filter(
    (e) =>
      !(
        page.type &&
        e.key === page.type.discriminator &&
        isFixedDiscriminator(e)
      ),
  );
  const typed = page.kind === "type" || page.kind === "type-index";
  const { top } = useSelection(entries.filter((e) => !e.link));
  const keys = (
    <>
      {page.kind === "output-variables" ? (
        <OutputVariables page={p} />
      ) : (
        entries.length > 0 && (
          <MasterDetail page={p} site={site} entries={entries} />
        )
      )}
    </>
  );
  return (
    <div className="pagehost reference" data-kind={page.kind}>
      <div className="crumb">
        {crumbs.map((c, i) => (
          <span key={i}>
            {i > 0 && " / "}
            {i === crumbs.length - 1 ? <b>{c}</b> : c}
          </span>
        ))}
      </div>
      <h1 className="page-h1">{page.title}</h1>
      <div className="hdr-controls">
        {page.type && (
          <span className="type-chip">
            {page.type.discriminator}: <b>{page.type.value}</b>
          </span>
        )}
        {entries.some((e) => e.facts?.advanced) && (
          <div className="hdr-toggles">
            <AdvancedToggle />
          </div>
        )}
      </div>
      {page.description &&
        (site.descriptions === "markdown" ? (
          <div className="lead">
            <EntryText text={page.description} route={page.route} />
          </div>
        ) : (
          <p className="lead">
            <Prose text={page.description} />
          </p>
        ))}
      {page.overridable_per_model && (
        <p className="crosshint">
          A mesh may set this block for itself. It lists only what differs;
          everything it leaves out comes from here.
        </p>
      )}
      {typed && <TypePills site={site} route={route} />}
      {page.kind === "type-index" && page.types?.length > 0 && (
        <div className="ntable-scroll">
          <table className="gtable reftable">
            <thead>
              <tr>
                <th>Type</th>
                <th>What it is</th>
              </tr>
            </thead>
            <tbody>
              {page.types.map((t) => (
                <tr key={t.route}>
                  <td className="gk">
                    <DocLink to={normRoute(t.route)}>{t.value}</DocLink>
                  </td>
                  <td>{t.description && <Prose text={t.description} />}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {page.outline ? (
        <div className="ref-pair">
          <div className="ref-keys">{keys}</div>
          <aside
            className="ref-pair-py"
            aria-label={`${LANGUAGE_NAMES[site.settingsLanguage] || "Example"} reference`}
          >
            <DeckOutline
              outline={page.outline}
              selected={top ? linkOf(p, top) : null}
            />
          </aside>
        </div>
      ) : (
        keys
      )}
      <Walkthrough w={page.walkthrough} />
    </div>
  );
}
