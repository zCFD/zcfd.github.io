import "katex/dist/katex.min.css";
import "./styles/index.css";
import { hydrateRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";
import { App } from "./components/App.jsx";
import { clientContent } from "./content.client.js";
import { leavesOf } from "./lib/nav.js";
import { routeFromPathname } from "./lib/routes.js";

const report = (kind) => (error, info) => {
  const msg = `[zdocs:${kind}] ${error?.message || error}`;
  (window.__zdocsErrors ||= []).push(msg);
  console.error(msg, info?.componentStack || "");
};

async function boot() {
  const baseEl = document.querySelector("base");
  const rootUrl = new URL(document.baseURI);
  if (baseEl) baseEl.setAttribute("href", rootUrl.href);
  const basename = rootUrl.pathname.replace(/\/$/, "");
  const content = clientContent();
  const leaves = leavesOf(content.site);
  const route = routeFromPathname(window.location.pathname, basename);
  const leaf = leaves.get(route === "/" ? content.site.landing : route);
  if (leaf) await content.preload(leaf);
  hydrateRoot(
    document.getElementById("root"),
    <BrowserRouter basename={basename || "/"}>
      <App content={{ ...content, leaves }} />
    </BrowserRouter>,
    {
      onRecoverableError: report("recoverable"),
      onCaughtError: report("caught"),
      onUncaughtError: report("uncaught"),
    },
  );
}
boot();
