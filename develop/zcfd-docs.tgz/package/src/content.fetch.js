import { pageKey } from "./lib/routes.js";

export class PayloadError extends Error {
  constructor(status, file) {
    super(`${file}: HTTP ${status}`);
    this.status = status;
  }
}

function once(load) {
  const promises = new Map();
  return (key) => {
    if (!promises.has(key)) promises.set(key, load(key));
    return promises.get(key);
  };
}

export async function fetchContent(base, init = {}) {
  const get = async (file, as) => {
    const res = await fetch(new URL(file, base), init);
    if (!res.ok) throw new PayloadError(res.status, file);
    return as === "json" ? res.json() : res.text();
  };
  const site = await get("site.json", "json");
  const findPage = once((key) => get(`pages${key}.md`));
  const getReference = once((route) => get(`ref${route}.json`, "json"));
  const getSvg = once((src) => get(`svg/${src}`));
  const getDecks = once((key) => get(`decks${key}.json`, "json"));
  const searchIndex = once(() =>
    get("search-index.json").then((text) =>
      URL.createObjectURL(new Blob([text], { type: "application/json" })),
    ),
  );
  return {
    site,
    searchIndexUrl: () => searchIndex("index"),
    getPage: (route) => findPage(pageKey(route)),
    getReference,
    getSvg,
    getDecks: (route) => getDecks(pageKey(route)),
    preload: (leaf) =>
      Promise.all([
        leaf.kind === "reference"
          ? getReference(leaf.route)
          : findPage(pageKey(leaf.route)),
        ...(leaf.svgs || []).map(getSvg),
      ]),
  };
}
