import site from "@payload/site.json";
import { pageKey } from "./lib/routes.js";

const pages = import.meta.glob("@payload/pages/**/*.md", {
  query: "?raw",
  import: "default",
});
const refs = import.meta.glob("@payload/ref/**/*.json", { import: "default" });
const decks = import.meta.glob("@payload/decks/**/*.json", {
  import: "default",
});
const svgs = import.meta.glob("@payload/svg/**/*.svg", {
  query: "?raw",
  import: "default",
});

function cached(table, prefix, ext) {
  const values = new Map();
  const promises = new Map();
  return (route) => {
    if (values.has(route)) return values.get(route);
    if (!promises.has(route)) {
      const suffix = `/${prefix}${route}${ext}`;
      const k = Object.keys(table).find((p) => p.endsWith(suffix));
      const p = k
        ? table[k]()
        : Promise.reject(new Error(`the payload has no ${route}`));
      promises.set(
        route,
        p.then((v) => {
          values.set(route, v);
          return v;
        }),
      );
    }
    return promises.get(route);
  };
}

export function clientContent() {
  const findPage = cached(pages, "pages", ".md");
  const getPage = (route) => findPage(pageKey(route));
  const getReference = cached(refs, "ref", ".json");
  const getSvg = cached(svgs, "svg/", "");
  const findDecks = cached(decks, "decks", ".json");
  return {
    site,
    searchIndexUrl: () => new URL("search-index.json", document.baseURI).href,
    getPage,
    getReference,
    getSvg,
    getDecks: (route) => findDecks(pageKey(route)),
    preload: (leaf) =>
      Promise.all([
        leaf.kind === "reference"
          ? getReference(leaf.route)
          : getPage(leaf.route),
        ...(leaf.svgs || []).map(getSvg),
      ]),
  };
}
