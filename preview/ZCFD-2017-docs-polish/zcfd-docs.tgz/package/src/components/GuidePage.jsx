import { Markdown } from "./Markdown.jsx";
import { DocLink } from "./DocLink.jsx";
import { headingsOf } from "../lib/directives.js";
import { slug } from "../lib/slug.js";

export function GuidePage({ leaf, body, crumbs }) {
  const toc = headingsOf(body, slug).filter((h) => h.depth === 2);
  return (
    <div className="pagehost guide" data-section={leaf.section}>
      <div className="crumb">
        {crumbs.map((c, i) => (
          <span key={i}>
            {i > 0 && " / "}
            {i === crumbs.length - 1 ? <b>{c}</b> : c}
          </span>
        ))}
      </div>
      <div className="guidewrap">
        <article className="guidedoc">
          <Markdown body={body} sourcePath={leaf.source} route={leaf.route} />
        </article>
        {toc.length > 1 && (
          <nav className="guide-toc" aria-label="On this page">
            <div className="toc-lab">On this page</div>
            {toc.map((h) => (
              <DocLink key={h.id} to={`${leaf.route}#${h.id}`}>
                {h.text}
              </DocLink>
            ))}
          </nav>
        )}
      </div>
    </div>
  );
}
