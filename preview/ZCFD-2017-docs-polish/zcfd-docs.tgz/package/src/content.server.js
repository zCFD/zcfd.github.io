import site from "@payload/site.json";
import { pageKey } from "./lib/routes.js";

const pages = import.meta.glob("@payload/pages/**/*.md", {
  query: "?raw",
  import: "default",
  eager: true,
});
const refs = import.meta.glob("@payload/ref/**/*.json", {
  import: "default",
  eager: true,
});
const svgs = import.meta.glob("@payload/svg/**/*.svg", {
  query: "?raw",
  import: "default",
  eager: true,
});

function finder(table, prefix, ext) {
  return (route) => {
    const suffix = `/${prefix}${route}${ext}`;
    const k = Object.keys(table).find((p) => p.endsWith(suffix));
    if (!k) throw new Error(`the payload has no ${route}`);
    return table[k];
  };
}

export function serverContent() {
  return {
    site,
    searchIndexUrl: () => new URL("search-index.json", document.baseURI).href,
    getPage: (route) => finder(pages, "pages", ".md")(pageKey(route)),
    getReference: finder(refs, "ref", ".json"),
    getSvg: finder(svgs, "svg/", ""),
  };
}
export { site };
